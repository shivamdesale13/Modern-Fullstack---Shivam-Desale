let claus = 'Claus Smith';
let Bobb = 'Bobb Martin';
let popo = 'popo doss';
let kaka = 'kaka Shookup';
let vvss = 'vvss Banks';
let shivam = 'Shivam Desale';
const element = /*#__PURE__*/React.createElement("ul", {
  style: {
    'color': 'blue',
    'fontSize': '24px'
  }
}, /*#__PURE__*/React.createElement("li", null, sally), /*#__PURE__*/React.createElement("li", null, mark), /*#__PURE__*/React.createElement("li", null, holly), /*#__PURE__*/React.createElement("li", null, amol), /*#__PURE__*/React.createElement("li", null, robin), /*#__PURE__*/React.createElement("li", null, bijal));
ReactDOM.render(element, document.getElementById('root'));